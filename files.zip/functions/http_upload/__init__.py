import logging
import os
import json
import uuid
from datetime import datetime
import azure.functions as func
from azure.storage.blob import BlobServiceClient
from azure.storage.queue import QueueClient

STORAGE_CONN = os.getenv("AZURE_STORAGE_CONNECTION_STRING") or os.getenv("AzureWebJobsStorage")
UPLOAD_CONTAINER = os.getenv("UPLOAD_CONTAINER", "uploads")
QUEUE_NAME = os.getenv("QUEUE_NAME", "validation-jobs")

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("HTTP upload function received a request.")
    try:
        # Get filename & profile from headers or query params
        filename = req.headers.get("X-Filename") or req.params.get("filename")
        profile = req.headers.get("X-Profile") or req.params.get("profile") or "A1"
        if not filename:
            return func.HttpResponse("Missing filename header (X-Filename) or ?filename", status_code=400)

        body = req.get_body()
        if not body:
            return func.HttpResponse("Empty request body: expected file bytes", status_code=400)

        blob_name = f"{datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')}_{uuid.uuid4().hex}_{filename}"
        # upload to blob
        bsc = BlobServiceClient.from_connection_string(STORAGE_CONN)
        container_client = bsc.get_container_client(UPLOAD_CONTAINER)
        try:
            container_client.create_container()
        except Exception:
            pass
        logging.info("Uploading file to blob: %s/%s", UPLOAD_CONTAINER, blob_name)
        blob_client = container_client.get_blob_client(blob_name)
        blob_client.upload_blob(body, overwrite=True)

        # enqueue job
        qc = QueueClient.from_connection_string(STORAGE_CONN, QUEUE_NAME)
        try:
            qc.create_queue()
        except Exception:
            pass
        job = {
            "upload_container": UPLOAD_CONTAINER,
            "upload_blob": blob_name,
            "profile": profile
        }
        qc.send_message(json.dumps(job))
        logging.info("Enqueued validation job for blob %s", blob_name)
        return func.HttpResponse(json.dumps({"status":"enqueued","blob":blob_name,"profile":profile}), status_code=202, mimetype="application/json")
    except Exception as e:
        logging.exception("Error handling upload")
        return func.HttpResponse(f"Server error: {e}", status_code=500)